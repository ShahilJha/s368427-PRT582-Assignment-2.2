# RULES

1. A random number will be generated at the start of the game.
2. The main theme of the game is to guess the randomly generated number.
3. When the number is entered, the program will respond with hints using ‘circle’ and
‘x’ to show how accurate the guess was
- A \'O\' indicates that one digit is correct and is in the right spot.
- A \'X\' indicates that one digit is correct but in the wrong spot.
- The number of such symbol represents the number of digits coresponding to the symbol.
--- 