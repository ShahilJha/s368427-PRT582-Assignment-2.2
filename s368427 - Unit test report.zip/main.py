from guess_number_game import guess_number_game # import the game class

# Create an instance of the game and start it
game = guess_number_game()
game.start_game()